# MATH375 HW 2

## script.m 

This is the main script file to run. Running this has a default value of x0 = 2 (can be changed on line 14).

Running this will bring up a plotting of the approximations against a plotting of the exact values of our function on a domain [-5, 5].

## function1.m

Please note: in the instructions it says to name this file `function.m`, but MATLAB appears to have issues with that since function is a keyword. Hence, .m file is `function1.m`.

This is simply the coded version of our found by hand f(x), followed by f'(x), also found by a simple derivative.